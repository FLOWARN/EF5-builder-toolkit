Jupyter Notebook for building the ML model for KW Parameter Estimation
===

[![Azure Notebooks](https://notebooks.azure.com/launch.png)](https://notebooks.azure.com/import/gh/hydroslab/ef5-kw-modeling)

This notebook shows how to train the SVR model to predict the kinematic wave alpha & beta parameters.
